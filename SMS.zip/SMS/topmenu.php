<?php

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];

?>

<div class="row">
				<div class="col-sm-8">
					<h3><a href="index.php" class="text-white">Store Management System</a></h3>
				</div>
				<div class="col-sm-4">
					<div class="row">
						<div class="col-sm-8">
							<h6 class="p-2">Hello<strong> <?php echo $users_first_name1.' '.$users_last_name1; ?></strong></h6>
						</div>
						<div class="col-sm-4">
							<h6 class="p-2"><a href="logout.php" class="font-weight-normal text-white">Logout</a></h6>
						</div>
					</div>
				</div>
			</div>
			
			<?php
}else{
	header("location:login.php");
}
?>