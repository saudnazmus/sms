-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2021 at 10:04 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(20) NOT NULL,
  `category_entry_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `category_entry_date`) VALUES
(1, 'Stationary', '2021-12-13'),
(2, 'Frouits', '2021-12-12'),
(3, 'Books', '2021-12-18'),
(4, 'Baby Food', '2021-12-14'),
(5, 'Electronics', '2021-12-03');

-- --------------------------------------------------------

--
-- Table structure for table `entryproduct`
--

CREATE TABLE `entryproduct` (
  `entry_product_id` int(11) NOT NULL,
  `entry_product_name` int(11) NOT NULL,
  `entry_product_code` int(11) NOT NULL,
  `entry_product_quentity` int(11) NOT NULL,
  `entry_product_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `entryproduct`
--

INSERT INTO `entryproduct` (`entry_product_id`, `entry_product_name`, `entry_product_code`, `entry_product_quentity`, `entry_product_date`) VALUES
(1, 1, 0, 150, '2021-12-14'),
(2, 2, 0, 300, '2021-12-02'),
(3, 2, 0, 50, '2021-12-13'),
(4, 2, 0, 30, '2021-12-14');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_category` int(3) NOT NULL,
  `product_code` varchar(6) NOT NULL,
  `product_entry_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_category`, `product_code`, `product_entry_date`) VALUES
(1, 'Khata', 1, 'kh0005', '2021-12-14'),
(2, 'Pen', 1, 'pe0055', '2021-12-13'),
(3, 'Big Khata', 1, '123', '2021-12-14'),
(4, 'Rabar', 1, 'rabar', '2021-12-08'),
(5, 'Markar', 1, 'mar005', '2021-11-30'),
(6, 'Smart Tv', 5, 'stv001', '2021-12-18'),
(7, 'Biomil', 4, 'bio003', '2021-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `spendproduct`
--

CREATE TABLE `spendproduct` (
  `spend_product_id` int(11) NOT NULL,
  `spend_product_name` int(11) NOT NULL,
  `spend_product_quentity` int(11) NOT NULL,
  `spend_product_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `spendproduct`
--

INSERT INTO `spendproduct` (`spend_product_id`, `spend_product_name`, `spend_product_quentity`, `spend_product_date`) VALUES
(1, 2, 12, '2021-12-12'),
(2, 1, 10, '2021-12-09'),
(3, 3, 50, '2021-12-01'),
(4, 4, 30, '2021-12-06'),
(5, 2, 50, '2021-12-12'),
(6, 2, 30, '2021-12-13'),
(7, 4, 5, '2021-12-17'),
(8, 5, 50, '2021-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `users_id` int(11) NOT NULL,
  `users_first_name` varchar(20) NOT NULL,
  `users_last_name` varchar(20) NOT NULL,
  `users_email` varchar(25) NOT NULL,
  `users_password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `users_first_name`, `users_last_name`, `users_email`, `users_password`) VALUES
(1, 'Nazmus', 'Saud', 'saud@gmail.com', '1234'),
(2, 'Ahnaf', 'Sabir', 'ahnaf@gmail.com', '123456'),
(3, 'Najmus', 'Saki', 'saki@gmail.com', ''),
(4, 'Monira', 'Babu', 'monira@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `entryproduct`
--
ALTER TABLE `entryproduct`
  ADD PRIMARY KEY (`entry_product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `spendproduct`
--
ALTER TABLE `spendproduct`
  ADD PRIMARY KEY (`spend_product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `entryproduct`
--
ALTER TABLE `entryproduct`
  MODIFY `entry_product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `spendproduct`
--
ALTER TABLE `spendproduct`
  MODIFY `spend_product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
