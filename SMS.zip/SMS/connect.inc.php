<?php
	$hostname = 'localhost';
	$username = 'root';
	$password = '';
	$databasename = 'sms_db';
	
	$conn = new mysqli($hostname, $username, $password, $databasename);
	if($conn->connect_error){
		die("Connection faild: " .$conn-connect_error);
	}
?>