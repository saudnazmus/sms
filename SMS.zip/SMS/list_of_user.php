<?php
	include('connect.inc.php');
?>

<?php
session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];

?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Users | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container p-5">
						<div class="row">
							<div class="col-sm-9">
								<h3>Users :</h3>
							</div>
							<div class="col-sm-3">
								<a href="add_user.php"><span class="btn btn-success">New User</span></a>
							</div>
						</div>
					
						<div class="container mt-4">
							<table class="table">
								<tr>
									<th>User Name</th><th>User's Email</th><th>Action</th>
								</tr>
									<?php
										$sql = "SELECT * FROM users";
					
										$result = $conn->query($sql);
										
										while($row = $result->fetch_assoc()){
										
											$users_id 		  = $row['users_id'];
											$users_first_name = $row['users_first_name'];
											$users_last_name  = $row['users_last_name'];
											$users_email      = $row['users_email'];
										
										echo "<tr>
												<td>$users_first_name $users_last_name</td> 
												<td>$users_email</td>
												<td><a href='edit_users.php?id=$users_id' class='btn btn-secondary'>Edit</a></td>
											</tr>";
									?>
									<?php }	?>
							</table>
						</div><!--end of container-->
					</div>
				</div>
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div><!-- end of container-foluid -->
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>