<?php
include('connect.inc.php');

session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];



if(isset($_GET['id'])){
	$get_id = $_GET['id'];
	
	$sql = "SELECT * FROM product WHERE product_id=$get_id";
				
	$result = $conn->query($sql);
	
	$row = $result->fetch_assoc();
	
	$product_id 		  = $row['product_id'];
	$product_name = $row['product_name'];
	$product_category  = $row['product_category'];
	$product_code  = $row['product_code'];
	$product_entry_date  = $row['product_entry_date'];
	
}

	
	if(isset($_POST['new_product_name'])  ){
		$new_product_name 		= $_POST['new_product_name'];
		$new_product_category   = $_POST['new_product_category'];
		$new_product_code 	  	= $_POST['new_product_code'];
		$new_product_entry_date = $_POST['new_product_entry_date'];
		$new_product_id 	  	= $_POST['new_product_id'];
		
		$sql1 = "UPDATE product
				SET product_name='$new_product_name', product_category='$new_product_category', product_code='$new_product_code',product_entry_date='$new_product_entry_date'
				WHERE product_id=$new_product_id";
				
		if($conn->query($sql1) === TRUE){
			echo $message = 'Update successful';
			header('location:list_of_product.php?message=Update Successful');
		}else{
			echo "Error updating record: " . $conn->error;
		}
	}
	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add Product | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container p-5">
						<h3>Edit Product</h3>
						<hr>
							<form action="edit_product.php" method="POST">
								Product Name : </br>
								<input type="text" name="new_product_name" value="<?php echo $product_name; ?>"></br></br>
								Product Category : </br>
								<select name="new_product_category">
									<?php 
										$sql_category = "SELECT * FROM category";
											
										$result_category = $conn->query($sql_category);
										while($row_category = $result_category->fetch_assoc()){

										$category_id 		  = $row_category['category_id'];
										$category_name 		  = $row_category['category_name'];
									?>
									<option value="<?php echo $category_id?>" <?php if($category_id==$product_category){ echo 'selected';} ?> ><?php echo $category_name ?></option>
										<?php } ?>
								</select></br></br>
								
								
								Product Code : </br>
								<input type="text" name="new_product_code" value="<?php echo $product_code  ?>"></br></br>
								Entry Date : </br>
								<input type="date" name="new_product_entry_date" value="<?php echo $product_entry_date  ?>"></br></br>
								<input type="text" name="new_product_id" value="<?php echo $product_id  ?>" hidden></br></br>
								<input type="submit" value="Submit" class="btn btn-success">
								<a href="list_of_product.php"><button type="button" class="btn btn-secondary">Cancel</button></a>
							</form>
					</div><!--end container -->
				</div><!--end col-sm-9 -->
			</div><!--row -->
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div><!--end container-foluid-->
	</body>
</html>


<?php
}else{
	header("location:login.php");
}
?>