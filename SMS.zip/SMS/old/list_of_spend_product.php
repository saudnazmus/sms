 <?php
	include('connect.inc.php');
	include('myfunction.php');

/*#########product List #######*/

	$product_list = array();
	
	$sql_cat = "SELECT * FROM product";
	
	$result_cat = $conn->query($sql_cat);
	
	while($row_cat = $result_cat->fetch_assoc()){
	
		$product_id   = $row_cat['product_id'];
		$product_name = $row_cat['product_name'];
		
		$product_list[$product_id] = $product_name;
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Spend Product | Stock Management System</title>
		<style>
			#button{
				background-color:#F00000;
				padding:2px 5px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid #F00000;
			}
			a{
				text-decoration:none;
			}
			#newEntry{
				background-color:green;
				padding:5px 8px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid green;
			}
			.addbutton{
				margin:10px 0;
			}
		</style>
	</head>
	
	<body>
		<header>
		
		</header>
		<div> <?php include('topmenu.php'); ?> </div>
		<div class="container">
		<table border=1>
						<tr>
							<td>Spend Product Name</td><td>Spend Product Quentity</td><td>Entry Date</td><td>Action</td>
						</tr>
			<?php
				$sql = "SELECT * FROM spendproduct";
				
				$result = $conn->query($sql);
				
				
				while($row = $result->fetch_assoc()){
				
					$spend_product_id 		  	= $row['spend_product_id'];
					$spend_product_name 		= $row['spend_product_name'];
					$spend_product_quentity  	= $row['spend_product_quentity'];
					$spend_product_date  		= $row['spend_product_date'];
					
				?>
						<tr>
							<?php echo "<td>$product_list[$spend_product_name]</td><td>$spend_product_quentity</td><td>$spend_product_date</td><td>
							<a href='edit_spend_product.php?id=$spend_product_id'> <span id='button'>Edit</span></a></td>";
							?>
						</tr>
				<?php }	?>
				</table>
		</div>
		<div class="addbutton">
			<a href="add_spend_product.php"><span id="newEntry">Add Spend Product</span></a>
		</div>
	</body>
</html>