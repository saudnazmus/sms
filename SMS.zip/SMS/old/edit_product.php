<?php
include('connect.inc.php');

if(isset($_GET['id'])){
	$get_id = $_GET['id'];
	
	$sql = "SELECT * FROM product WHERE product_id=$get_id";
				
	$result = $conn->query($sql);
	
	$row = $result->fetch_assoc();
	
	$product_id 		  = $row['product_id'];
	$product_name = $row['product_name'];
	$product_category  = $row['product_category'];
	$product_code  = $row['product_code'];
	$product_entry_date  = $row['product_entry_date'];
	
}

	
	if(isset($_POST['new_product_name'])  ){
		$new_product_name 		= $_POST['new_product_name'];
		$new_product_category   = $_POST['new_product_category'];
		$new_product_code 	  	= $_POST['new_product_code'];
		$new_product_entry_date = $_POST['new_product_entry_date'];
		$new_product_id 	  	= $_POST['new_product_id'];
		
		$sql1 = "UPDATE product
				SET product_name='$new_product_name', product_category='$new_product_category', product_code='$new_product_code',product_entry_date='$new_product_entry_date'
				WHERE product_id=$new_product_id";
				
		if($conn->query($sql1) === TRUE){
			echo 'Update successful';
			header('location:list_of_product.php');
		}else{
			echo "Error updating record: " . $conn->error;
		}
	}
	
?>
<div> <?php include('topmenu.php'); ?> </div>
<form action="edit_product.php" method="POST">
	Product Name : </br>
	<input type="text" name="new_product_name" value="<?php echo $product_name; ?>"></br></br>
	Product Category : </br>
	<select name="new_product_category">
		<?php 
			$sql_category = "SELECT * FROM category";
				
			$result_category = $conn->query($sql_category);
			while($row_category = $result_category->fetch_assoc()){

			$category_id 		  = $row_category['category_id'];
			$category_name 		  = $row_category['category_name'];
		?>
		<option value="<?php echo $category_id?>" <?php if($category_id==$product_category){ echo 'selected';} ?> ><?php echo $category_name ?></option>
			<?php } ?>
	</select></br></br>
	
	
	Product Code : </br>
	<input type="text" name="new_product_code" value="<?php echo $product_code  ?>"></br></br>
	Entry Date : </br>
	<input type="date" name="new_product_entry_date" value="<?php echo $product_entry_date  ?>"></br></br>
	<input type="text" name="new_product_id" value="<?php echo $product_id  ?>" hidden></br></br>
	<input type="submit" value="submit">
	
</form>