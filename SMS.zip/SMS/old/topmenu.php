

<div class="container">
				<a href="index.php">Home</a> | 
				<a href="list_of_category.php">Category</a> | 
				<a href="list_of_product.php.">Product</a> |
				<a href="list_of_entry_product.php">Entry Product </a> | 
				<a href="list_of_spend_product.php">Spend Product</a> |
				<a href="report.php">Report</a> |
			</div>