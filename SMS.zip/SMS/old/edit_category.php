<?php
include('connect.inc.php');

if(isset($_GET['id'])){
	$get_id = $_GET['id'];
	
	$sql = "SELECT * FROM category WHERE category_id=$get_id";
				
	$result = $conn->query($sql);
	
	$row = $result->fetch_assoc();
	
	$category_id 		  = $row['category_id'];
	$category_name = $row['category_name'];
	$category_entry_date  = $row['category_entry_date'];
	
}

	
	if(isset($_POST['category_name'])  ){
		$new_category_name = $_POST['category_name'];
		$new_category_entry_date  = $_POST['category_entry_date'];
		$new_category_id 	  = $_POST['new_category_id'];
		
		$sql1 = "UPDATE category
				SET category_name='$new_category_name', category_entry_date='$new_category_entry_date'
				WHERE category_id=$new_category_id";
				
		if($conn->query($sql1) === TRUE){
			echo 'Update successful';
			header('location:list_of_category.php');
		}else{
			echo "Error updating record: " . $conn->error;
		}
	}
	
?>
<div> <?php include('topmenu.php'); ?> </div>
<form action="edit_category.php" method="POST">
	Category : </br>
	<input type="text" name="category_name" value="<?php echo $category_name ?>"></br></br>
	Category Entry Date : </br>
	<input type="date" name="category_entry_date" value="<?php echo $category_entry_date ?>"></br></br>
	<input type="text" name="new_category_id" value="<?php echo $category_id ?>" hidden ></br></br>
	<input type="submit" value="submit">
</form>