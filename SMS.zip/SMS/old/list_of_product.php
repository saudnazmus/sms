<?php
	include('connect.inc.php');

/*#########category List #######*/

	$category_list = array();
	
	$sql_cat = "SELECT * FROM category";
	
	$result_cat = $conn->query($sql_cat);
	
	while($row_cat = $result_cat->fetch_assoc()){
	
		$category_id   = $row_cat['category_id'];
		$category_name = $row_cat['category_name'];
		
		$category_list[$category_id] = $category_name;
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Product | Stock Management System</title>
		<style>
			#button{
				background-color:#F00000;
				padding:2px 5px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid #F00000;
			}
			a{
				text-decoration:none;
			}
			#newEntry{
				background-color:green;
				padding:5px 8px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid green;
			}
			.addbutton{
				margin:10px 0;
			}
		</style>
	</head>
	
	<body>
		<header>
		
		</header>
		<div> <?php include('topmenu.php'); ?> </div>
		<div class="container">
		<table border=1>
						<tr>
							<td>Product Name</td><td>Product Category</td><td>Product Code</td><td>Action</td>
						</tr>
			<?php
				$sql = "SELECT * FROM product";
				
				$result = $conn->query($sql);
				
				
				while($row = $result->fetch_assoc()){
				
					$product_id 		  	= $row['product_id'];
					$product_name 		  	= $row['product_name'];
					$product_category  	  	= $row['product_category'];
					$product_code  			= $row['product_code'];
					$product_entry_date  	= $row['product_entry_date'];
				?>
						<tr>
							<?php echo "<td>$product_name</td><td>$category_list[$product_category]</td><td>$product_code</td><td>
							<a href='edit_product.php?id=$product_id'> <span id='button'>Edit</span></a></td>";
							?>
						</tr>
				<?php }	?>
				</table>
		</div>
		<div class="addbutton">
			<a href="add_product.php"><span id="newEntry">Add Product</span></a>
		</div>
	</body>
</html>


<?php
/*
	$category_list = array();
	
	$sql_cat = "SELECT * FROM category";
				
				$result_cat = $conn->query($sql_cat);
				
				
				while($row_cat = $result_cat->fetch_assoc()){
				
					 $category_id  		  	= $row_cat['category_id'];
					 $category_name 		  	= $row_cat['category_name'];
					
					$category_list[$category_id] = $category_name;
				}
				
	echo $category_list[0];*/
?>