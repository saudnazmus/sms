 <?php
	include('connect.inc.php');
	include('myfunction.php');
	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Entry Product | Stock Management System</title>
	</head>
	
	<body>
		<header>
			<div> <?php include('topmenu.php'); ?> </div>
			<div class="container">
				<?php
					if(isset($_POST['entry_product_name'])){
						
						$entry_product_name 	 = $_POST['entry_product_name'];
						$entry_product_quentity  = $_POST['entry_product_quentity'];
						$entry_product_date  	 = $_POST['entry_product_date'];
						
						$sql = "INSERT INTO entryproduct (entry_product_name, entry_product_quentity, entry_product_date)
							   VALUES ('$entry_product_name', '$entry_product_quentity', '$entry_product_date')";
						
						if($conn->query($sql) == TRUE){
							echo 'Record inserted!';
						}else{
							echo $sql. "".$conn->error;
						}
					}
				?>
				<form action="add_entry_product.php" method="POST">
					Product Name : </br>
					<select name="entry_product_name">
						<?php dropdownItem('product','product_id','product_name'); ?>
					</select></br></br>
					Product Quentity : </br>
					<input type="text" name="entry_product_quentity"></br></br>
					
					Entry Date : </br>
					<input type="date" name="entry_product_date"></br></br>
					<input type="submit" value="submit">
				</form>
			</div>
		</header>
	</body>
</html>