  <?php
	include('connect.inc.php');
	include('myfunction.php');
	
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Spend Product | Stock Management System</title>
	</head>
	
	<body>
		<header>
			<div> <?php include('topmenu.php'); ?> </div>
			<div class="container">
				<?php
					if(isset($_POST['spend_product_name'])){
						if(!empty($_POST['spend_product_name'])){
							$spend_product_name 	 = $_POST['spend_product_name'];
							$spend_product_quentity  = $_POST['spend_product_quentity'];
							$spend_product_date  	 = $_POST['spend_product_date'];
							
							$sql = "INSERT INTO spendproduct (spend_product_name, 	spend_product_quentity, spend_product_date)
								   VALUES ('$spend_product_name', '$spend_product_quentity', '$spend_product_date')";
							
							if($conn->query($sql) == TRUE){
								echo 'Record inserted!';
							}else{
								echo $sql. "".$conn->error;
							}
						}
					}
				?>
				<form action="add_spend_product.php" method="POST">
					Product Name : </br>
					<select name="spend_product_name">
						<option>--Select Product--</option>
						<?php dropdownItem('product','product_id','product_name'); ?>
					</select></br></br>
					Spend Product Quentity : </br>
					<input type="text" name="spend_product_quentity"></br></br>
					
					Entry Date : </br>
					<input type="date" name="spend_product_date"></br></br>
					<input type="submit" value="submit">
				</form>
			</div>
		</header>
	</body>
</html>