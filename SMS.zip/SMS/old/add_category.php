<?php
	include('connect.inc.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add Category | Stock Management System</title>
	</head>
	
	<body>
		<header>
			<div> <?php include('topmenu.php'); ?> </div>
			<div class="container">
				<?php
					if(isset($_POST['category_name'])){
						$category_name 		  = $_POST['category_name'];
						$category_entry_date  = $_POST['category_entry_date'];
						
						$sql = "INSERT INTO category (category_name, category_entry_date)
							   VALUES ('$category_name', '$category_entry_date')";
						
						if($conn->query($sql) == TRUE){
							echo 'Record inserted!';
						}else{
							echo $sql. "".$conn->error;
						}
					}
				?>
				<form action="add_category.php" method="POST">
					Category Name : </br>
					<input type="text" name="category_name"></br></br>
					Entry Date : </br>
					<input type="date" name="category_entry_date"></br></br>
					<input type="submit" value="submit">
				</form>
			</div>
		</header>
	</body>
</html>