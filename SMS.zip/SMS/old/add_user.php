<?php
	$hostname = 'localhost';
	$username = 'root';
	$password = '';
	$databasename = 'sms_db';
	
	$conn = new mysqli($hostname, $username, $password, $databasename);
	if($conn->connect_error){
		die("Connection faild: " .$conn-connect_error);
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Add User | Stock Management System</title>
	</head>
	
	<body>
		<header>
			<div> <?php include('topmenu.php'); ?> </div>
			<div class="container">
				<?php
					if(isset($_POST['users_first_name'])){
						$users_first_name = $_POST['users_first_name'];
						$users_last_name  = $_POST['users_last_name'];
						$users_email      = $_POST['users_email'];
						$users_password   = $_POST['users_password'];
						
						$sql = "INSERT INTO users (users_first_name, users_last_name, users_email, users_password)
							   VALUES ('$users_first_name', '$users_last_name', '$users_email', '$users_password')";
						
						if($conn->query($sql) == TRUE){
							echo 'Record inserted!';
						}else{
							echo $sql. "".$conn->error;
						}
					}
					
					
				?>
				<form action="add_user.php" method="POST">
					First Name : </br>
					<input type="text" name="users_first_name"></br></br>
					Last Name : </br>
					<input type="text" name="users_last_name"></br></br>
					Email : </br>
					<input type="text" name="users_email"></br></br>
					Password : </br>
					<input type="password" name="users_password"></br></br>
					<input type="submit" value="submit">
				</form>
			</div>
		</header>
	</body>
</html>