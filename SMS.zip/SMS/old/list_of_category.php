<?php
	include('connect.inc.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Category | Stock Management System</title>
		<style>
			#button{
				background-color:#F00000;
				padding:2px 5px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid #F00000;
			}
			a{
				text-decoration:none;
			}
			#newEntry{
				background-color:green;
				padding:5px 8px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid green;
			}
		</style>
	</head>
	
	<body>
		<header>
		
		</header>
		<div> <?php include('topmenu.php'); ?> </div>
		<div class="container">
			<?php
				$sql = "SELECT * FROM category";
				
				$result = $conn->query($sql);
				
				while($row = $result->fetch_assoc()){
				
					$category_id 		  = $row['category_id'];
					$category_name 		  = $row['category_name'];
					$category_entry_date  = $row['category_entry_date'];
					
					echo $category_name.' '.$category_entry_date;
				?>
					<a href="edit_category.php?id=<?php echo $category_id ?> "> <span id="button">Edit</span></a>
					
					<br><br>
				<?php }	?>
		</div>
		<div>
			<a href="add_category.php"><span id="newEntry">Add Category</span></a>
		</div>
	</body>
</html>