<?php
	include('connect.inc.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Users | Stock Management System</title>
		<style>
			#button{
				background-color:#F00000;
				padding:2px 5px;
				color:#FFFFFF;
				border-radius:5px;
				border: 1px solid #F00000;
			}
			a{
				text-decoration:none;
			}
		</style>
	</head>
	
	<body>
		<header>
		
		</header>
		<div> <?php include('topmenu.php'); ?> </div>
		<div class="container">
			<?php
				$sql = "SELECT * FROM users";
				
				$result = $conn->query($sql);
				
				while($row = $result->fetch_assoc()){
				
					$users_id 		  = $row['users_id'];
					$users_first_name = $row['users_first_name'];
					$users_last_name  = $row['users_last_name'];
					$users_email      = $row['users_email'];
					
					echo $users_first_name.' '.$users_last_name.' '.$users_email;
				?>
					<a href="edit_users.php?id=<?php echo $users_id ?> "> <span id="button">Edit</span></a>
					
					<br><br>
				<?php }	?>
		</div>
	</body>
</html>