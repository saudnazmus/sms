<?php
	include('connect.inc.php');
	session_start();
	if(empty($_SESSION['users_first_name1']) && empty($_SESSION['users_last_name1']) ){
?>
 <!DOCTYPE html>
 <html>
	<head>
		<title>Log In</title>
	</head>
	
	<body>
		<?php
			if(isset($_POST['email']) && $_POST['password']){
				$email 		= $_POST['email'];
				$password 	= $_POST['password'];
				
				$sql = "SELECT * FROM users WHERE users_email='$email' AND users_password='$password' ";
				
				$result = $conn->query($sql);
				
				if($result->num_rows > 0){
					$row = $result->fetch_assoc();
					
					$users_first_name  =  $row['users_first_name'];
					$users_last_name   =  $row['users_last_name'];
					
					$_SESSION['users_first_name1']  = $users_first_name;
					$_SESSION['users_last_name1']   = $users_last_name;
					
					header('location:index.php');
				}else{
					echo 'Error Login';
				}
			}
			
		
		?>
	
		<form action="login.php" method="POST">
			Email : <br>
			<input type="email" name="email"><br><br>
			Password : <br>
			<input type="password" name="password"><br><br>
			<input type="Submit" value="Login"><br><br>
		</form>
	</body>
	
 </html>
 
 <?php
}else{
	header("location:index.php");
}
?>