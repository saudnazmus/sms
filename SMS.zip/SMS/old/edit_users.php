<?php
include('connect.inc.php');

if(isset($_GET['id'])){
	$get_id = $_GET['id'];
	
	$sql = "SELECT * FROM users WHERE users_id=$get_id";
				
	$result = $conn->query($sql);
	
	$row = $result->fetch_assoc();
	
	$users_id 		  = $row['users_id'];
	$users_first_name = $row['users_first_name'];
	$users_last_name  = $row['users_last_name'];
	$users_email      = $row['users_email'];
}

	
	if(isset($_POST['users_first_name']) && isset($_POST['new_users_id']) ){
		$new_users_first_name = $_POST['users_first_name'];
		$new_users_last_name  = $_POST['users_last_name'];
		$new_users_email 	  = $_POST['users_email'];
		$new_users_id 	  	  = $_POST['new_users_id'];
		
		$sql1 = "UPDATE users
				SET users_first_name='$new_users_first_name', users_last_name='$new_users_last_name', users_email = '$new_users_email'
				WHERE users_id=$new_users_id";
				
		if($conn->query($sql1) === TRUE){
			echo 'Update successful';
			header('location:list_of_user.php');
		}else{
			echo "Error updating record: " . $conn->error;
		}
	}
	
?>
<div> <?php include('topmenu.php'); ?> </div>
<form action="edit_users.php" method="POST">
	First Name : </br>
	<input type="text" name="users_first_name" value="<?php echo $users_first_name ?>"></br></br>
	Last Name : </br>
	<input type="text" name="users_last_name" value="<?php echo $users_last_name ?>"></br></br>
	Email : </br>
	<input type="text" name="users_email" value="<?php echo $users_email ?>"></br></br>
	<input type="text" name="new_users_id" value="<?php echo $users_id ?>" hidden ></br></br>
	<input type="submit" value="submit">
</form>