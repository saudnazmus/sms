  <?php
	include('connect.inc.php');
	include('myfunction.php');
	
	session_start();

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Report | Stock Management System</title>
		
		<script>

			function print(parameter)
			{

				var prtContent = document.getElementById(parameter).innerHTML;
				var WinPrint = window.open('', '', 'left=0,top=0,width=1200,height=900,toolbar=0,scrollbars=0,status=0');
				WinPrint.document.write(prtContent);
				WinPrint.document.close();
				WinPrint.focus();
				WinPrint.print();
				WinPrint.close();

			}

		</script>
	</head>
	
	<body>
		<header>
			<div> <?php include('topmenu.php'); ?> </div></br>
			<div class="container">
				<?php
				$sql = "SELECT * FROM product";
				
				$result = $conn->query($sql);
				$list_of_product = array();
				
				while($row = $result->fetch_assoc()){
				
					$product_id 		  	= $row['product_id'];
					$product_name 		  	= $row['product_name'];
					$product_category  	  	= $row['product_category'];
					$product_code  			= $row['product_code'];
					$product_entry_date  	= $row['product_entry_date'];
					
					$list_of_product[$product_id] = $product_name
				?>
				<?php }	?>
				
				<form action="report.php" method="GET">
				<select name="product_name">
					<?php
						foreach ($list_of_product as $key=>$value){
							echo "<option value='$key'>$value</option>";
						}
					?>
				</select>
				<input type="submit" value="submit">
				
			</div>
			
			<div style='text-align:center;'><button class='button2' onclick="print('report_content')">Print</button></div>
			<div id='report_content'>
				<div>
					<?php
					if(isset($_GET['product_name'])){
						$get_prduct = $_GET['product_name'];
						
					
						$sql1 = "SELECT * FROM entryproduct WHERE entry_product_name = $get_prduct";
						
						$result1 = $conn->query($sql1);
						
						echo "<h1>$list_of_product[$get_prduct]</h1> <h3>List of Entry Product</h3>";
						echo "<table border=1px>
									<tr><td>Entry Date</td><td>Quentity</td></tr>";
									
						$entryProductArray = array();
						
						while($row1 = $result1->fetch_assoc()){
						
							$entry_product_quentity 		  	= $row1['entry_product_quentity'];
							$entry_product_date  	  	= $row1['entry_product_date'];
							
							echo "<tr><td>$entry_product_date</td><td>$entry_product_quentity</td></tr>";
							
							$entryProductArray[] = $entry_product_quentity;
						}
						
						//Entry Product Jog korar jonno;
						$countProductarray = count($entryProductArray);
					
						$addingEntrySpend = 0;
						
						for($i=0;$i<$countProductarray;$i++){
							$entryArrayItem = $entryProductArray[$i];
							$addingEntrySpend = $addingEntrySpend + $entryArrayItem;
						}
						echo "<tr><td>Total</td><td>$addingEntrySpend</td></tr>";
					
						echo "</table>"
					?>
					
					
						<h3>List of Spend Product</h3>
						<?php
							$sql2 = "SELECT * FROM spendproduct WHERE spend_product_name = $get_prduct";
							
							$result2 = $conn->query($sql2);
							
							echo "<table border=1px>
										<tr><td>Entry Date</td><td>Quentity</td></tr>";
										
							$spendProductArray = array();
										
							while($row2 = $result2->fetch_assoc()){
							
								$spend_product_quentity = $row2['spend_product_quentity'];
								$spend_product_date  	= $row2['spend_product_date'];
								
								echo "<tr><td>$spend_product_date</td><td>$spend_product_quentity</td></tr>";
								
								$spendProductArray[] = $spend_product_quentity;
							}
						
						
						//Spend Product Jog korar jonno;
						$countarray = count($spendProductArray);
						
						$addingSpend = 0;
						
						for($i=0;$i<$countarray;$i++){
							$spendArrayItem = $spendProductArray[$i];
							$addingSpend = $addingSpend + $spendArrayItem;
						}
						echo "<tr><td>Total</td><td>$addingSpend</td></tr>";
						
						echo "</table>";
						
						$suspensProduct = $addingEntrySpend - $addingSpend;
						
						echo "<h4>Suspens : $suspensProduct</h4>";
					}
					?>
					
				</div>
			</div>
		</header>
	</body>
</html>