<?php
session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){

?>

<!DOCTYPE html>
<html>
	<head>
		<title>SMS | Store Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>
	</head>
	
	<body>
	
		<header class="container-foluid bg-success text-white p-2">
			<div class="row">
				<div class="col-sm-8">
					<h3>Store Management System</h3>
				</div>
				<div class="col-sm-4">
					<div class="row">
						<div class="col-sm-8">
							<h6 class="p-2">Hello Nazmus Saud</h6>
						</div>
						<div class="col-sm-4">
							<h6 class="p-2"><a href="logout.php" class="font-weight-normal text-white">Logout</a></h6>
						</div>
					</div>
				</div>
			</div>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<h5 class="bg-success text-white px-2 py-1">Master Part</h5>
					<ul class="list-group">
						<li class="list-group-item"><a href="list_of_category.php" class="text-dark">Category</a></li>
						<li class="list-group-item"><a href="list_of_product.php." class="text-dark">Product</a> </li>
					</ul>
					<h5 class="bg-success text-white px-2 py-1 mt-3">Entry Part</h5>
					<ul class="list-group ">
						<li class="list-group-item"><a href="list_of_entry_product.php" class="text-dark">Store Product </a> </li> 
						<li class="list-group-item"><a href="list_of_spend_product.php" class="text-dark">Spend Product</a> </li>
					</ul>
					<h5 class="bg-success text-white px-2 py-1 mt-3">Report Part</h5>
					<ul class="list-group ">
						<li class="list-group-item"><a href="report.php" class="text-dark">Report</a> </li>
					</ul>
					<h5 class="bg-success text-white px-2 py-1 mt-3">User Part</h5>
					<ul class="list-group ">
						<li class="list-group-item"><a href="logout.php" class="text-dark">User List</a></li>
					</ul>
				</div>
				<div class="col-sm-9">
						<div class="container p-5">
							<ul class="nav">
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-folder-plus fa-5x text-success"></i><br> Add category</a> </li>
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-folder-open fa-5x text-success"></i><br> Category List</a> </li>
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-plus-square fa-5x text-success"></i><br> Add Product</a> </a> </li>
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-th fa-5x text-success"></i><br> Product List</a> </a> </li>
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-box fa-5x text-success"></i><br>Store Product</a> </a> </li>
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-box-open fa-5x text-success"></i><br>Spend Product</a> </a> </li>
							</ul>
							<ul class="nav">
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-table fa-5x text-success"></i><br>Report</a> </a> </li>
							</ul>
							<ul class="nav">
								<li class="nav-item p-4"><a href="report.php" class="text-none"><i class="fas fa-users fa-5x text-success"></i><br>Users</a> </a> </li>
							</ul>
					</div>
				</div>
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div>
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>