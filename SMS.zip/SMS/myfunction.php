<?php

function dropdownItem($tablename,$columnOne,$columnTwo){
	include('connect.inc.php');
	$sql = "SELECT * FROM $tablename";
				
	$result = $conn->query($sql);
	while($row = $result->fetch_assoc()){
		$product_id 		  = $row[$columnOne];
		$product_name 		  = $row[$columnTwo];
		echo "<option value=$product_id> $product_name</option>";
	}
							
}

/*
function diplayItem($tablename,$columnOne,$columnTwo){
	include('connect.inc.php');
	
	$category_list = array();
	
	$sql_cat = "SELECT * FROM $tablename";
	
	$result_cat = $conn->query($sql_cat);
	
	while($row_cat = $result_cat->fetch_assoc()){
	
		$category_id   = $row_cat[$columnOne];
		$category_name = $row_cat[$columnTwo];
		
		$category_list[$category_id] = $category_name;
	}
	return $category_list;
}

diplayItem('product','product_id','product_name');
echo $category_list['$entry_product_name'];
*/


function category_list($tablename,$id,$name)
{

	include('connect.inc.php');
	
	
	$sql = "SELECT * FROM $tablename";
	$rec = $conn->query($sql);
	
	$category_array = array();
	
	while($row = mysqli_fetch_array($rec))
	{
		$category_id = $row[$id];
		$category_name = $row[$name];
		
		
		
		$category_array[$category_id] = $category_name;
	}
	
	return $category_array;
}




?>