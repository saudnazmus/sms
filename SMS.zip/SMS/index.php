<?php
session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];

?>

<!DOCTYPE html>
<html>
	<head>
		<title>SMS | Store Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>
	</head>
	
	<body>
	
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
						<div class="container p-5">
							<ul class="nav">
								<li class="nav-item p-3"><a href="add_category.php" class="text-none h6"><i class="fas fa-folder-plus fa-3x text-success"></i><br> Add category</a> </li>
								<li class="nav-item p-3"><a href="list_of_category.php" class="text-none h6"><i class="fas fa-folder-open fa-3x text-success"></i><br> Category List</a> </li>
								<li class="nav-item p-3"><a href="add_product.php" class="text-none h6"><i class="fas fa-plus-square fa-3x text-success"></i><br> Add Product</a> </a> </li>
								<li class="nav-item p-3"><a href="list_of_product.php" class="text-none h6"><i class="fas fa-th fa-3x text-success"></i><br> Product List</a> </a> </li>
								<li class="nav-item p-3"><a href="add_entry_product.php" class="text-none h6"><i class="fas fa-box fa-3x text-success"></i><br>Store Product</a> </a> </li>
								<li class="nav-item p-3"><a href="add_spend_product.php" class="text-none h6"><i class="fas fa-box-open fa-3x text-success"></i><br>Spend Product</a> </a> </li>
							</ul>
							<hr/>
							<ul class="nav">
								<li class="nav-item p-3"><a href="report.php" class="text-none h6"><i class="fas fa-table fa-3x text-success"></i><br>Report</a> </a> </li>
							</ul>
							<hr/>
							<ul class="nav">
								<li class="nav-item p-3"><a href="report.php" class="text-none h6"><i class="fas fa-users fa-3x text-success"></i><br>Users</a> </a> </li>
							</ul>
					</div>
				</div>
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div>
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>