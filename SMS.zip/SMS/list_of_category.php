<?php
	include('connect.inc.php');
?>

<?php
session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];

?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Category | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container p-5">
						<div class="row">
							<div class="col-sm-9">
								<h3>Category :</h3>
							</div>
							<div class="col-sm-3">
								<a href="add_category.php"><span class="btn btn-success">New Category</span></a>
							</div>
						</div>
					
						<div class="container mt-4">
							<table class="table">
								<tr>
									<th>Category Name</th><th>Entry Date</th><th>Action</th>
								</tr>
									<?php
									$sql = "SELECT * FROM category";
									
									$result = $conn->query($sql);
									
									while($row = $result->fetch_assoc()){
									
										$category_id 		  = $row['category_id'];
										$category_name 		  = $row['category_name'];
										$category_entry_date  = $row['category_entry_date'];
										
										echo "<tr>
												<td>$category_name</td> 
												<td>$category_entry_date</td>
												<td><a href='edit_category.php?id=$category_id' class='btn btn-secondary'>Edit</a></td>
											</tr>";
									?>
									<?php }	?>
							</table>
						</div><!--end of container-->
					</div>
				</div>
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div><!-- end of container-foluid -->
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>