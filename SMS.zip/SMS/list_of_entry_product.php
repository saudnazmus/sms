 <?php
	include('connect.inc.php');
	include('myfunction.php');
	

session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];



/*#########category List #######*/

	$product_list = array();
	
	$sql_cat = "SELECT * FROM product";
	
	$result_cat = $conn->query($sql_cat);
	
	while($row_cat = $result_cat->fetch_assoc()){
	
		$product_id   = $row_cat['product_id'];
		$product_name = $row_cat['product_name'];
		
		$product_list[$product_id] = $product_name;
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Product | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container p-5">
						<div class="row">
							<div class="col-sm-9">
								<h3>Stored Product :</h3>
							</div>
							<div class="col-sm-3">
								<a href="add_entry_product.php"><span class="btn btn-success">Store Product</span></a>
							</div>
						</div>
					
						<div class="container mt-4">
							<table class="table">
								<tr>
									<th>Product Name</th><th>Product Quentity</th><th>Entry Date</th><th>Action</th>
								</tr>
								<?php
									$sql = "SELECT * FROM entryproduct";
									
									$result = $conn->query($sql);
									
									
									while($row = $result->fetch_assoc()){
									
										$entry_product_id 		  	= $row['entry_product_id'];
										$entry_product_name 		= $row['entry_product_name'];
										$entry_product_quentity  	= $row['entry_product_quentity'];
										$entry_product_date  		= $row['entry_product_date'];
										
									?>
											<tr>
												<?php echo "<td>$product_list[$entry_product_name]</td><td>$entry_product_quentity</td><td>$entry_product_date</td><td>
												<a href='edit_entry_product.php?id=$entry_product_id'> <span class='btn btn-secondary'>Edit</span></a></td>";
												?>
											</tr>
								<?php }	?>
							</table>
						</div><!--end of container-->
					</div>
				</div>
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div><!-- end of container-foluid -->
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>