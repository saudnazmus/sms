<?php

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];

?>

<h5 class="bg-success text-white px-2 py-1">Master Part</h5>
					<ul class="list-group">
						<li class="list-group-item"><a href="list_of_category.php" class="text-dark">Category</a></li>
						<li class="list-group-item"><a href="list_of_product.php." class="text-dark">Product</a> </li>
					</ul>
					<h5 class="bg-success text-white px-2 py-1 mt-3">Entry Part</h5>
					<ul class="list-group ">
						<li class="list-group-item"><a href="list_of_entry_product.php" class="text-dark">Store Product </a> </li> 
						<li class="list-group-item"><a href="list_of_spend_product.php" class="text-dark">Spend Product</a> </li>
					</ul>
					<h5 class="bg-success text-white px-2 py-1 mt-3">Report Part</h5>
					<ul class="list-group ">
						<li class="list-group-item"><a href="report.php" class="text-dark">Report</a> </li>
					</ul>
					<h5 class="bg-success text-white px-2 py-1 mt-3">User Part</h5>
					<ul class="list-group ">
						<li class="list-group-item"><a href="list_of_user.php" class="text-dark">User List</a></li>
					</ul>
					
					<?php
}else{
	header("location:login.php");
}
?>