<?php
	include('connect.inc.php');
	

session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];



/*#########category List #######*/

	$category_list = array();
	
	$sql_cat = "SELECT * FROM category";
	
	$result_cat = $conn->query($sql_cat);
	
	while($row_cat = $result_cat->fetch_assoc()){
	
		$category_id   = $row_cat['category_id'];
		$category_name = $row_cat['category_name'];
		
		$category_list[$category_id] = $category_name;
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>List of Product | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container p-5">
						<?php if(isset($_GET['message'])){
								echo $_GET['message'];
							}							
						?>
						<div class="row">
							<div class="col-sm-9">
								<h3>Product Item :</h3>
							</div>
							<div class="col-sm-3">
								<a href="add_product.php"><span class="btn btn-success">New Product</span></a>
							</div>
						</div>
					
						<div class="container mt-4">
							<table class="table">
								<tr>
									<td>Product Name</td><td>Product Category</td><td>Product Code</td><td>Action</td>
								</tr>
									<?php
										$sql = "SELECT * FROM product";
										
										$result = $conn->query($sql);
										
										
										while($row = $result->fetch_assoc()){
										
											$product_id 		  	= $row['product_id'];
											$product_name 		  	= $row['product_name'];
											$product_category  	  	= $row['product_category'];
											$product_code  			= $row['product_code'];
											$product_entry_date  	= $row['product_entry_date'];
										?>
												<tr>
													<?php echo "<td>$product_name</td><td>$category_list[$product_category]</td><td>$product_code</td><td>
													<a href='edit_product.php?id=$product_id' class='btn btn-secondary'>Edit</a></td>";
													?>
												</tr>
										<?php }	?>
								</table>
						</div><!--end of container-->
					</div>
				</div>
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div><!-- end of container-foluid -->
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>