  <?php
	include('connect.inc.php');
	include('myfunction.php');

?>

<?php
session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Report | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
		
		<script>

			function print(parameter)
			{

				var prtContent = document.getElementById(parameter).innerHTML;
				var WinPrint = window.open('', '', 'left=0,top=0,width=1200,height=900,toolbar=0,scrollbars=0,status=0');
				WinPrint.document.write(prtContent);
				WinPrint.document.close();
				WinPrint.focus();
				WinPrint.print();
				WinPrint.close();

			}

		</script>
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container my-4">
						<?php
							$sql = "SELECT * FROM product";
							
							$result = $conn->query($sql);
							$list_of_product = array();
							
							while($row = $result->fetch_assoc()){
							
								$product_id 		  	= $row['product_id'];
								$product_name 		  	= $row['product_name'];
								$product_category  	  	= $row['product_category'];
								$product_code  			= $row['product_code'];
								$product_entry_date  	= $row['product_entry_date'];
								
								$list_of_product[$product_id] = $product_name
							?>
							<?php }	?>
							
							<form action="report.php" method="GET">
							<select name="product_name">
								<?php
									foreach ($list_of_product as $key=>$value){
										echo "<option value='$key'>$value</option>";
									}
								?>
							</select>
							<input type="submit" value="submit">
					</div><!--end of container-->
					<div id='report_content'>
							<?php
							if(isset($_GET['product_name'])){
								$get_prduct = $_GET['product_name'];
								
								$sql1 = "SELECT * FROM entryproduct WHERE entry_product_name = $get_prduct";
								
								$result1 = $conn->query($sql1);
								
								echo "";
								?>
								<div class='row border-bottom border-top mb-3 py-2'>
									<div class='col-sm-10'>
										<h1>Product Name : <?php echo $list_of_product[$get_prduct];?></h1>
									</div>
									<div class='col-sm-2'>
										
									</div>
								</div>
						<div class="row mx-4">
							<div class="col-sm-6">
								<?php
									echo "<h4>List of Entry Product</h4>";
								echo "<table class='table'>
											<tr><td>Entry Date</td><td>Quentity</td></tr>";
											
								$entryProductArray = array();
								
								while($row1 = $result1->fetch_assoc()){
								
									$entry_product_quentity 		  	= $row1['entry_product_quentity'];
									$entry_product_date  	  	= $row1['entry_product_date'];
									
									echo "<tr><td>$entry_product_date</td><td>$entry_product_quentity</td></tr>";
									
									$entryProductArray[] = $entry_product_quentity;
								}
								
								//Entry Product Jog korar jonno;
								$countProductarray = count($entryProductArray);
							
								$addingEntrySpend = 0;
								
								for($i=0;$i<$countProductarray;$i++){
									$entryArrayItem = $entryProductArray[$i];
									$addingEntrySpend = $addingEntrySpend + $entryArrayItem;
								}
								echo "<tr><td><strong>Total</strong></td><td><strong>$addingEntrySpend</strong></td></tr>";
							
								echo "</table>"
							?>
								</div><!--end col-sm-6 -->
								<div class="col-sm-6 border-left">
									<h4>List of Spend Product</h4>
									<?php
										$sql2 = "SELECT * FROM spendproduct WHERE spend_product_name = $get_prduct";
										
										$result2 = $conn->query($sql2);
										
										echo "<table class='table'>
													<tr><td>Entry Date</td><td>Quentity</td></tr>";
													
										$spendProductArray = array();
													
										while($row2 = $result2->fetch_assoc()){
										
											$spend_product_quentity = $row2['spend_product_quentity'];
											$spend_product_date  	= $row2['spend_product_date'];
											
											echo "<tr><td>$spend_product_date</td><td>$spend_product_quentity</td></tr>";
											
											$spendProductArray[] = $spend_product_quentity;
										}
									
									
										//Spend Product Jog korar jonno;
										$countarray = count($spendProductArray);
										
										$addingSpend = 0;
										
										for($i=0;$i<$countarray;$i++){
											$spendArrayItem = $spendProductArray[$i];
											$addingSpend = $addingSpend + $spendArrayItem;
										}
										echo "<tr><td><strong>Total</strong></td><td><strong>$addingSpend</strong></td></tr>";
										
										echo "</table>";
								?>
								</div>
						</div><!-- row -->
						<div class="container mt-5">
							<div class="row">
								<div class="col-sm-4">
								</div>
								<div class="col-sm-4">
									<?php 
										$suspensProduct = $addingEntrySpend - $addingSpend;
										echo "<h4 class=''>Suspens : $suspensProduct</h4>";
									?>
								</div>
								<div class="col-sm-4">
								</div>
							</div>
						</div>
						<?php } ?>
					</div><!-- report print -->
					<button class='btn btn-success' onclick="print('report_content')">Print</button>
				</div>
				
			</div>
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
			</div>
		</div><!-- end of container-foluid -->
		</div>
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>