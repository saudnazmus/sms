<?php
	include('connect.inc.php');
	include('myfunction.php');
	

session_start();

if(!empty($_SESSION['users_first_name1']) && !empty($_SESSION['users_last_name1']) ){
	
	$users_first_name1 = $_SESSION['users_first_name1'];
	$users_last_name1  = $_SESSION['users_last_name1'];


	
	
	if(isset($_GET['id'])){
	$get_id = $_GET['id'];
	
	$sql = "SELECT * FROM spendproduct WHERE spend_product_id=$get_id";
				
	$result = $conn->query($sql);
	
	$row = $result->fetch_assoc();
	
	$spend_product_id 		  = $row['spend_product_id'];
	$spend_product_name = $row['spend_product_name'];
	$spend_product_quentity  = $row['spend_product_quentity'];
	$spend_product_date  = $row['spend_product_date'];
	
}

	
	if(isset($_POST['new_spend_product_name'])  ){
		$new_spend_product_name 	= $_POST['new_spend_product_name'];
		$new_spend_product_quentity = $_POST['new_spend_product_quentity'];
		$new_spend_product_date 	= $_POST['new_spend_product_date'];
		
		$new_spend_product_id 	= $_POST['new_spend_product_id'];
		
		
		$sql1 = "UPDATE spendproduct
				SET spend_product_name='$new_spend_product_name', spend_product_quentity='$new_spend_product_quentity', spend_product_date='$new_spend_product_date'
				WHERE spend_product_id=$new_spend_product_id";
				
		if($conn->query($sql1) === TRUE){
			echo 'Update successful';
			header('location:list_of_spend_product.php');
		}else{
			echo "Error updating record: " . $conn->error;
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Edit Spand Product | Stock Management System</title>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	
	<body>
		<header class="container-foluid bg-success text-white p-2">
			<?php include('topmenu.php'); ?>
		</header>
		
		<div class="container-foluid">
			<div class="row">
				<div class="col-sm-3 bg-light border-right border-success pt-4 pr-0">
					<?php include('leftmenu.php');?>
				</div>
				<div class="col-sm-9">
					<div class="container p-5">
						<h3>Edit Spend Product</h3>
						<hr>
						<form action="edit_spend_product.php" method="POST">
							Spend Product Name : </br>
							<select name="new_spend_product_name" <?php  ?>>
								<?php 
									$sql_product_name = "SELECT * FROM product";
										
									$result_product_name = $conn->query($sql_product_name);
									while($row_product_name = $result_product_name->fetch_assoc()){

									$product_id 		  = $row_product_name['product_id'];
									$product_name 		  = $row_product_name['product_name'];
								?>
								<option value="<?php echo $product_id?>" <?php if($product_id==$spend_product_name){ echo 'selected';} ?> ><?php echo $product_name ?></option>
									<?php } ?>
							</select></br></br>
							Spend Product Quentity : </br>
							<input type="text" name="new_spend_product_quentity" value="<?php echo $spend_product_quentity; ?>"></br></br>
							
							Spend Date : </br>
							<input type="date" name="new_spend_product_date" value="<?php echo $spend_product_date ?>"></br></br>
							<input type="text" name="new_spend_product_id" value="<?php echo $spend_product_id; ?>" hidden></br></br>
							<input type="submit" value="Submit" class="btn btn-success">
							<a href="list_of_spend_product.php"><button type="button" class="btn btn-secondary">Cancel</button></a>
						</form>
					</div><!--end container -->
				</div><!--end col-sm-9 -->
			</div><!--row -->
			<div class="container-fould border-top border-success ">
				<p class="p-1 text-center">SMS - Stock Management System | Developed By : Nazmus Saud</p>
			</div>
		</div><!--end container-foluid-->
	</body>
</html>

<?php
}else{
	header("location:login.php");
}
?>